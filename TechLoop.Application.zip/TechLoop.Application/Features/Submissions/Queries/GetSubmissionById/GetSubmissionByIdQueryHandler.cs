﻿using MediatR;
using TechLoop.Application.Features.Submissions.DTOs;
using TechLoop.Application.Interfaces.Repositories;

namespace TechLoop.Application.Features.Submissions.Queries.GetSubmissionById;

public sealed class GetSubmissionByIdQueryHandler : IRequestHandler<GetSubmissionByIdQuery, SubmissionResponse?>
{
    private readonly ISubmissionRepository _submissionRepository;
    public GetSubmissionByIdQueryHandler(ISubmissionRepository submissionRepository)
    {
        _submissionRepository = submissionRepository;
    }

    public async Task<SubmissionResponse?> Handle(GetSubmissionByIdQuery request, CancellationToken cancellationToken)
    {
        var submission = await _submissionRepository.GetByIdAsync(request.Id, cancellationToken);
        if (submission is null)
            return null;

        return new SubmissionResponse
        {
            Id = submission.Id,
            UserId = submission.UserId,
            QuestionId = submission.QuestionId,
            TechnologyId = submission.TechnologyId,
            SourceCode = submission.SourceCode,
            Status = submission.Status,
            ExecutionTimeMs = submission.ExecutionTimeMs,
            MemoryUsedMb = submission.MemoryUsedMb,
            PassedTestCases = submission.PassedTestCases,
            TotalTestCases = submission.TotalTestCases,
            Score = submission.Score,
            SubmittedAt = submission.SubmittedAt,
            CompilerOutput = submission.CompilerOutput,
            RuntimeOutput = submission.RuntimeOutput,
            AiReview = submission.AiReview,
            JudgeToken = submission.JudgeToken
        };
    }
}