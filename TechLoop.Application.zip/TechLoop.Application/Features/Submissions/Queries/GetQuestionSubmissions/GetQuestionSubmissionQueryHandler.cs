﻿using MediatR;
using TechLoop.Application.Features.Submissions.DTOs;
using TechLoop.Application.Interfaces.Repositories;

namespace TechLoop.Application.Features.Submissions.Queries.GetQuestionSubmissions;

public sealed class GetQuestionSubmissionsQueryHandler : IRequestHandler<GetQuestionSubmissionsQuery, IEnumerable<SubmissionResponse>>
{
    private readonly ISubmissionRepository _submissionRepository;
    public GetQuestionSubmissionsQueryHandler(ISubmissionRepository submissionRepository)
    {
        _submissionRepository = submissionRepository;
    }

    public async Task<IEnumerable<SubmissionResponse>> Handle(GetQuestionSubmissionsQuery request, CancellationToken cancellationToken)
    {
        var submissions = await _submissionRepository.GetByQuestionIdAsync(request.QuestionId, cancellationToken);
        return submissions.Select(submission => new SubmissionResponse
        {
            Id = submission.Id,
            UserId = submission.UserId,
            QuestionId = submission.QuestionId,
            TechnologyId = submission.TechnologyId,
            SourceCode = submission.SourceCode,
            Status = submission.Status,
            ExecutionTimeMs = submission.ExecutionTimeMs,
            MemoryUsedMb = submission.MemoryUsedMb,
            PassedTestCases = submission.PassedTestCases,
            TotalTestCases = submission.TotalTestCases,
            Score = submission.Score,
            SubmittedAt = submission.SubmittedAt,
            CompilerOutput = submission.CompilerOutput,
            RuntimeOutput = submission.RuntimeOutput,
            AiReview = submission.AiReview,
            JudgeToken = submission.JudgeToken
        });
    }
}