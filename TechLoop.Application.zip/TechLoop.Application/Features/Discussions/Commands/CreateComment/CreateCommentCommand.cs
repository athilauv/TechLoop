﻿using MediatR;
using TechLoop.Application.Features.Discussions.DTOs;

namespace TechLoop.Application.Features.DiscussionComments.Commands.CreateComment;

public sealed class CreateCommentCommand : IRequest<DiscussionCommentDto>
{
    public int DiscussionId { get; set; }

    public int? ParentCommentId { get; set; }

    public string Content { get; set; } = string.Empty;
}