﻿namespace TechLoop.Application.DTOs.Auth;
public class RefreshRequest
{
    public string RefreshToken { get; set; } = string.Empty;
}