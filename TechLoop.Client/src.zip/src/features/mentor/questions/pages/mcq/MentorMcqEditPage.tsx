import { ArrowLeft, Save } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
    getMentorQuestionById,
    updateQuestion,
} from "../../../../../api/mentorQuestion.api.ts";

import Breadcrumb from "../../../../../shared/Breadcrumb";
import Button from "../../../../../shared/Button";
import LoadingSpinner from "../../../../../shared/LoadingSpinner";

import {
    DifficultyLevel,
} from "../../../../../types/enums/difficulty-level.ts";

import type {
    MentorQuestion,
    UpdateQuestionRequest,
} from "../../../../../types/question.types.ts";

const MentorMcqEditPage = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();

    const questionId = Number(id);

    const [question, setQuestion] =
        useState<MentorQuestion | null>(null);

    const [subTopicId, setSubTopicId] =
        useState("");

    const [title, setTitle] =
        useState("");

    const [slug, setSlug] =
        useState("");

    const [description, setDescription] =
        useState("");

    const [mark, setMark] =
        useState("");

    const [hint, setHint] =
        useState("");

    const [explanation, setExplanation] =
        useState("");

    const [difficulty, setDifficulty] =
        useState<DifficultyLevel>(
            DifficultyLevel.Beginner,
        );

    const [position, setPosition] =
        useState("");

    const [imageUrl, setImageUrl] =
        useState("");

    const [loading, setLoading] =
        useState(true);

    const [submitting, setSubmitting] =
        useState(false);

    const [error, setError] =
        useState<string | null>(null);

    useEffect(() => {
        if (
            !questionId ||
            Number.isNaN(questionId)
        ) {
            setLoading(false);
            setError("Invalid question ID.");
            return;
        }

        let cancelled = false;

        const loadQuestion = async () => {
            try {
                const result =
                    await getMentorQuestionById(
                        questionId,
                    );

                if (cancelled) {
                    return;
                }

                setQuestion(result);
                setSubTopicId(
                    String(result.subTopicId),
                );
                setTitle(result.title);
                setSlug(result.slug);
                setDescription(
                    result.description,
                );
                setMark(String(result.mark));
                setHint(result.hint ?? "");
                setExplanation(
                    result.explanation ?? "",
                );
                setDifficulty(result.difficulty);
                setPosition(
                    String(result.position),
                );
                setImageUrl(
                    result.imageUrl ?? "",
                );
            } catch {
                if (!cancelled) {
                    setError(
                        "Unable to load the question.",
                    );
                }
            } finally {
                if (!cancelled) {
                    setLoading(false);
                }
            }
        };

        void loadQuestion();

        return () => {
            cancelled = true;
        };
    }, [questionId]);

    const handleTitleChange = (
        value: string,
    ) => {
        setTitle(value);
    };

    const handleSubmit = async (
        event: React.FormEvent<HTMLFormElement>,
    ) => {
        event.preventDefault();

        if (!question) {
            return;
        }

        const request: UpdateQuestionRequest = {
            subTopicId: Number(subTopicId),
            questionType: question.questionType,
            title: title.trim(),
            slug: slug.trim(),
            description: description.trim(),
            imageUrl:
                imageUrl.trim() || undefined,
            mark: Number(mark),
            hint: hint.trim(),
            explanation:
                explanation.trim(),
            difficulty,
            position: Number(position),
        };

        try {
            setSubmitting(true);
            setError(null);

            await updateQuestion(
                questionId,
                request,
            );

            navigate(
                `/mentor/questions/mcq/${questionId}`,
            );
        } catch {
            setError(
                "Unable to update the question. Please try again.",
            );
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center py-20">
                <LoadingSpinner />
            </div>
        );
    }

    if (!question) {
        return (
            <div className="min-h-full px-6 py-6">
                <div className="mx-auto max-w-4xl">
                    <p className="text-sm text-[var(--cs-danger)]">
                        {error ??
                            "Question not found."}
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-full px-6 py-6">
            <Breadcrumb
                items={[
                    {
                        label: "Questions",
                        onClick: () =>
                            navigate(
                                "/mentor/questions/mcq",
                            ),
                    },
                    {
                        label: "MCQ Questions",
                        onClick: () =>
                            navigate(
                                "/mentor/questions/mcq",
                            ),
                    },
                    {
                        label: question.title,
                        onClick: () =>
                            navigate(
                                `/mentor/questions/mcq/${questionId}`,
                            ),
                    },
                    {
                        label: "Edit",
                    },
                ]}
            />

            <div className="mx-auto mt-6 max-w-4xl">
                <button
                    type="button"
                    onClick={() =>
                        navigate(
                            `/mentor/questions/mcq/${questionId}`,
                        )
                    }
                    className="mb-5 inline-flex items-center gap-2 text-sm text-[var(--cs-text-muted)] transition-colors hover:text-[var(--cs-text)]"
                >
                    <ArrowLeft size={17} />
                    Back to Question
                </button>

                <section className="rounded-xl border border-[var(--cs-border)] bg-[var(--cs-surface)] p-6">
                    <div>
                        <h1 className="text-xl font-semibold text-[var(--cs-text)]">
                            Edit MCQ Question
                        </h1>

                        <p className="mt-1 text-sm text-[var(--cs-text-muted)]">
                            Update the question details.
                        </p>
                    </div>

                    {error && (
                        <div className="mt-5 rounded-lg border border-[var(--cs-danger-border)] bg-[var(--cs-danger-subtle)] px-4 py-3 text-sm text-[var(--cs-danger)]">
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        className="mt-6 space-y-6"
                    >
                        <div className="grid gap-5 sm:grid-cols-2">
                            <div>
                                <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                    Sub Topic ID
                                </label>

                                <input
                                    type="number"
                                    min={1}
                                    value={subTopicId}
                                    onChange={(event) =>
                                        setSubTopicId(
                                            event.target
                                                .value,
                                        )
                                    }
                                    required
                                    className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                                />
                            </div>

                            <div>
                                <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                    Position
                                </label>

                                <input
                                    type="number"
                                    min={1}
                                    value={position}
                                    onChange={(event) =>
                                        setPosition(
                                            event.target
                                                .value,
                                        )
                                    }
                                    required
                                    className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                Title
                            </label>

                            <input
                                type="text"
                                value={title}
                                onChange={(event) =>
                                    handleTitleChange(
                                        event.target
                                            .value,
                                    )
                                }
                                required
                                className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                            />
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                Slug
                            </label>

                            <input
                                type="text"
                                value={slug}
                                onChange={(event) =>
                                    setSlug(
                                        event.target
                                            .value,
                                    )
                                }
                                required
                                className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                            />
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                Description
                            </label>

                            <textarea
                                value={description}
                                onChange={(event) =>
                                    setDescription(
                                        event.target
                                            .value,
                                    )
                                }
                                required
                                rows={6}
                                className="w-full resize-y rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-3 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                            />
                        </div>

                        <div className="grid gap-5 sm:grid-cols-2">
                            <div>
                                <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                    Marks
                                </label>

                                <input
                                    type="number"
                                    min={1}
                                    value={mark}
                                    onChange={(event) =>
                                        setMark(
                                            event.target
                                                .value,
                                        )
                                    }
                                    required
                                    className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                                />
                            </div>

                            <div>
                                <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                    Difficulty
                                </label>

                                <select
                                    value={difficulty}
                                    onChange={(event) =>
                                        setDifficulty(
                                            Number(
                                                event
                                                    .target
                                                    .value,
                                            ) as DifficultyLevel,
                                        )
                                    }
                                    className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                                >
                                    <option value={1}>
                                        Beginner
                                    </option>
                                    <option value={2}>
                                        Easy
                                    </option>
                                    <option value={3}>
                                        Medium
                                    </option>
                                    <option value={4}>
                                        Hard
                                    </option>
                                    <option value={5}>
                                        Expert
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                Image URL
                            </label>

                            <input
                                type="url"
                                value={imageUrl}
                                onChange={(event) =>
                                    setImageUrl(
                                        event.target
                                            .value,
                                    )
                                }
                                placeholder="https://..."
                                className="w-full rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-2.5 text-sm text-[var(--cs-text)] outline-none placeholder:text-[var(--cs-text-muted)] focus:border-[var(--cs-primary)]"
                            />
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                Hint
                            </label>

                            <textarea
                                value={hint}
                                onChange={(event) =>
                                    setHint(
                                        event.target
                                            .value,
                                    )
                                }
                                rows={4}
                                className="w-full resize-y rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-3 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                            />
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-[var(--cs-text)]">
                                Explanation
                            </label>

                            <textarea
                                value={explanation}
                                onChange={(event) =>
                                    setExplanation(
                                        event.target
                                            .value,
                                    )
                                }
                                rows={5}
                                className="w-full resize-y rounded-lg border border-[var(--cs-border)] bg-[var(--cs-surface-muted)] px-3 py-3 text-sm text-[var(--cs-text)] outline-none focus:border-[var(--cs-primary)]"
                            />
                        </div>

                        <div className="flex justify-end gap-3 border-t border-[var(--cs-border)] pt-5">
                            <Button
                                type="button"
                                variant="secondary"
                                onClick={() =>
                                    navigate(
                                        `/mentor/questions/mcq/${questionId}`,
                                    )
                                }
                                disabled={
                                    submitting
                                }
                            >
                                Cancel
                            </Button>

                            <Button
                                type="submit"
                                disabled={
                                    submitting ||
                                    !subTopicId ||
                                    !title.trim() ||
                                    !slug.trim() ||
                                    !description.trim() ||
                                    Number(mark) <=
                                    0 ||
                                    Number(position) <=
                                    0
                                }
                            >
                                <span className="inline-flex items-center gap-2">
                                    <Save size={16} />

                                    {submitting
                                        ? "Updating..."
                                        : "Update MCQ"}
                                </span>
                            </Button>
                        </div>
                    </form>
                </section>
            </div>
        </div>
    );
};

export default MentorMcqEditPage;