import { useQuery, useQueryClient } from "@tanstack/react-query";
import Breadcrumb from "../../../../../shared/Breadcrumb.tsx";
import { showToast } from "../../../../../utils/toast.tsx";

import {
    getMentorDiscussions,
    pinDiscussion,
    unpinDiscussion,
} from "../../../../../api/mentorDiscussion.api.ts";

import {
    createDiscussionComment,
    deleteDiscussionComment,
    getDiscussionComments,
    updateDiscussionComment,
} from "../../../../../api/discussion.api.ts";

import type {
    Discussion,
    DiscussionComment,
} from "../../../../../types/discussion.types.ts";

import { useCurrentUserId } from "../../../../../hooks/useCurrentUserId.ts";

import DiscussionList from "../../../../common/Discussion/components/DiscussionList.tsx";
import PinToggleButton from "../../components/discussions/PinToggleButton.tsx";

const MentorDiscussionsPage = () => {
    const queryClient = useQueryClient();
    const currentUserId = useCurrentUserId();

    const {
        data: discussions = [],
        isLoading,
        isError,
    } = useQuery<Discussion[]>({
        queryKey: ["mentor-discussions"],
        queryFn: getMentorDiscussions,
    });

    const invalidateDiscussions = async () => {
        await queryClient.invalidateQueries({
            queryKey: ["mentor-discussions"],
        });
    };

    // ============================================================
    // PIN / UNPIN
    // ============================================================

    const handleTogglePin = async (
        discussion: Discussion,
    ) => {
        try {
            if (discussion.isPinned) {
                await unpinDiscussion(discussion.id);

                showToast.success(
                    "Discussion unpinned.",
                );
            } else {
                await pinDiscussion(discussion.id);

                showToast.success(
                    "Discussion pinned.",
                );
            }

            await invalidateDiscussions();
        } catch (error) {
            showToast.error(
                error instanceof Error
                    ? error.message
                    : "Failed to update pin status.",
            );
        }
    };

    // ============================================================
    // CREATE COMMENT
    // ============================================================

    const handleCreateComment = async (
        discussion: Discussion,
        content: string,
    ): Promise<void> => {
        try {
            await createDiscussionComment(
                discussion.id,
                {
                    content,
                    parentCommentId: null,
                },
            );

            await invalidateDiscussions();
        } catch (error) {
            showToast.error(
                error instanceof Error
                    ? error.message
                    : "Failed to post comment.",
            );

            throw error;
        }
    };

    // ============================================================
    // REPLY TO COMMENT
    // ============================================================

    const handleReplyComment = async (
        discussion: Discussion,
        comment: DiscussionComment,
        content: string,
    ): Promise<void> => {
        try {
            await createDiscussionComment(
                discussion.id,
                {
                    content,
                    parentCommentId: comment.id,
                },
            );

            await invalidateDiscussions();
        } catch (error) {
            showToast.error(
                error instanceof Error
                    ? error.message
                    : "Failed to post reply.",
            );

            throw error;
        }
    };

    // ============================================================
    // EDIT COMMENT
    // ============================================================

    const handleEditComment = async (
        _discussion: Discussion,
        comment: DiscussionComment,
        content: string,
    ): Promise<void> => {
        try {
            await updateDiscussionComment(
                comment.id,
                {
                    content,
                },
            );

            await invalidateDiscussions();

            showToast.success(
                "Comment updated successfully.",
            );
        } catch (error) {
            showToast.error(
                error instanceof Error
                    ? error.message
                    : "Failed to update comment.",
            );

            throw error;
        }
    };

    // ============================================================
    // DELETE COMMENT
    // ============================================================

    const handleDeleteComment = async (
        _discussion: Discussion,
        comment: DiscussionComment,
    ): Promise<void> => {
        try {
            await deleteDiscussionComment(
                comment.id,
            );

            await invalidateDiscussions();

            showToast.success(
                "Comment deleted successfully.",
            );
        } catch (error) {
            showToast.error(
                error instanceof Error
                    ? error.message
                    : "Failed to delete comment.",
            );

            throw error;
        }
    };

    return (
        <div className="min-h-full px-6 py-6">
            <Breadcrumb
                items={[
                    {
                        label: "Discussions",
                    },
                ]}
            />

            <div className="mx-auto mt-6 max-w-4xl">
                <div>
                    <h1 className="text-xl font-bold text-[var(--cs-text)]">
                        All Discussions
                    </h1>

                    <p className="mt-1 text-sm text-[var(--cs-text-muted)]">
                        Browse learner discussions across every question,
                        participate in conversations, and pin useful discussions.
                    </p>
                </div>

                <div className="mt-6">
                    <DiscussionList
                        discussions={discussions}
                        isLoading={isLoading}
                        isError={isError}
                        currentUserId={currentUserId}
                        fetchComments={getDiscussionComments}

                        onCreateComment={
                            handleCreateComment
                        }

                        onReplyComment={
                            handleReplyComment
                        }

                        onEditComment={
                            handleEditComment
                        }

                        onDeleteComment={
                            handleDeleteComment
                        }

                        renderExtraAction={(discussion) => (
                            <PinToggleButton
                                isPinned={
                                    discussion.isPinned
                                }
                                onToggle={() =>
                                    void handleTogglePin(
                                        discussion,
                                    )
                                }
                            />
                        )}

                        renderContextSlot={(
                            discussion,
                        ) => (
                            <span className="text-[var(--cs-text-muted)]">
                                Question #
                                {discussion.questionId}
                            </span>
                        )}

                        emptyTitle="No discussions"
                        emptyDescription="There are no learner discussions yet."
                    />
                </div>
            </div>
        </div>
    );
};

export default MentorDiscussionsPage;