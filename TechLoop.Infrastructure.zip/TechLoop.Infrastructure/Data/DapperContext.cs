﻿using System.Data;
using Microsoft.Extensions.Configuration;
using Npgsql;
using TechLoop.Application.Interfaces.Infrastructure;
using TechLoop.Domain.Enums;

namespace TechLoop.Infrastructure.Data;

public class DapperContext : IDapperContext
{
    private readonly NpgsqlDataSource _dataSource;
    public DapperContext(IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection")!;
        Console.WriteLine(typeof(SubmissionStatus).Assembly.FullName);
        var builder = new NpgsqlDataSourceBuilder(connectionString);
        builder.MapEnum<SubmissionStatus>("submission_status");
        _dataSource = builder.Build();
    }

    public IDbConnection CreateConnection()
    {
        return _dataSource.OpenConnection();
    }
}