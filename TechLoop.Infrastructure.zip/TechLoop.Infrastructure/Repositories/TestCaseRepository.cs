﻿using Dapper;
using TechLoop.Application.Interfaces.Infrastructure;
using TechLoop.Application.Interfaces.Repositories;
using TechLoop.Domain.Entities;

namespace TechLoop.Infrastructure.Repositories;

public sealed class TestCaseRepository : ITestCaseRepository
{
    private readonly IDapperContext _context;
    public TestCaseRepository(IDapperContext context)
    {
        _context = context;
    }

    // Position exists
    public async Task<bool> PositionExistsAsync(int questionId, int position, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT EXISTS
(
    SELECT 1
    FROM test_cases
    WHERE question_id = @QuestionId
      AND position = @Position
      AND deleted_at IS NULL
);";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<bool>(
            new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId,
                    Position = position
                },
                cancellationToken: cancellationToken));
    }

    // Create
    public async Task<int> CreateAsync(TestCase testCase, CancellationToken cancellationToken)
    {
        const string sql = @"
INSERT INTO test_cases
(
    question_id,
    input,
    expected_output,
    is_hidden,
    position,
    created_by,
    created_at
)
VALUES
(
    @QuestionId,
    @Input,
    @ExpectedOutput,
    @IsHidden,
    @Position,
    @CreatedBy,
    @CreatedAt
)
RETURNING id;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<int>(
            new CommandDefinition(sql, testCase, cancellationToken: cancellationToken));
    }

    // Update
    public async Task<int> UpdateAsync(TestCase testCase, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE test_cases
SET
    input = @Input,
    expected_output = @ExpectedOutput,
    is_hidden = @IsHidden,
    position = @Position,
    updated_by = @UpdatedBy,
    updated_at = @UpdatedAt
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(new CommandDefinition(sql, testCase, cancellationToken: cancellationToken));
    }

    // Soft delete
    public async Task<int> SoftDeleteAsync(int id, Guid deletedBy, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE test_cases
SET
    deleted_by = @DeletedBy,
    deleted_at = @DeletedAt
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(new CommandDefinition(sql,
                new
                {
                    Id = id,
                    DeletedBy = deletedBy,
                    DeletedAt = DateTime.UtcNow
                },
                cancellationToken: cancellationToken));
    }
    
    // Soft delete by Question
    public async Task<int> SoftDeleteByQuestionIdAsync(int questionId, Guid deletedBy, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE test_cases
SET
    deleted_by = @DeletedBy,
    deleted_at = @DeletedAt
WHERE question_id = @QuestionId
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId,
                    DeletedBy = deletedBy,
                    DeletedAt = DateTime.UtcNow
                },
                cancellationToken: cancellationToken));
    }

    // Get by id
    public async Task<TestCase?> GetByIdAsync(int id, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    input,
    expected_output AS ExpectedOutput,
    is_hidden AS IsHidden,
    position,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM test_cases
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<TestCase>(
            new CommandDefinition(
                sql,
                new { Id = id },
                cancellationToken: cancellationToken));
    }

    // Get By Question
    public async Task<IEnumerable<TestCase>> GetByQuestionIdAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    input,
    expected_output AS ExpectedOutput,
    is_hidden AS IsHidden,
    position,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM test_cases
WHERE question_id = @QuestionId
AND deleted_at IS NULL
ORDER BY position;";

        using var connection = _context.CreateConnection();
        return await connection.QueryAsync<TestCase>(new CommandDefinition(sql, 
            new { QuestionId = questionId },
                cancellationToken: cancellationToken));
    }
    
    // Get Visible Test Cases (Learner)
    public async Task<IEnumerable<TestCase>> GetVisibleByQuestionIdAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    input,
    expected_output AS ExpectedOutput,
    is_hidden AS IsHidden,
    position,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM test_cases
WHERE question_id = @QuestionId
AND is_hidden = FALSE
AND deleted_at IS NULL
ORDER BY position;";

        using var connection = _context.CreateConnection();
        return await connection.QueryAsync<TestCase>(new CommandDefinition(sql,
                new
                {
                    QuestionId = questionId
                },
                cancellationToken: cancellationToken));
    }
}