﻿using Dapper;
using TechLoop.Application.Interfaces.Infrastructure;
using TechLoop.Application.Interfaces.Repositories;
using TechLoop.Domain.Entities;

namespace TechLoop.Infrastructure.Repositories;

public sealed class CodingTemplateRepository : ICodingTemplateRepository
{
    private readonly IDapperContext _context;
    public CodingTemplateRepository(IDapperContext context)
    {
        _context = context;
    }

    // Exists
    public async Task<bool> ExistsAsync(int questionId, int technologyId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT EXISTS
(
    SELECT 1
    FROM coding_templates
    WHERE question_id = @QuestionId
      AND technology_id = @TechnologyId
      AND deleted_at IS NULL
);";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<bool>(new CommandDefinition(sql,
                new
                {
                    QuestionId = questionId,
                    TechnologyId = technologyId
                },
                cancellationToken: cancellationToken));
    }

    // Create
    public async Task<int> CreateAsync(CodingTemplate template, CancellationToken cancellationToken)
    {
        const string sql = @"
INSERT INTO coding_templates
(
    question_id,
    technology_id,
    starter_code,
    solution_code,
    created_by,
    created_at
)
VALUES
(
    @QuestionId,
    @TechnologyId,
    @StarterCode,
    @SolutionCode,
    @CreatedBy,
    @CreatedAt
)
RETURNING id;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<int>(new CommandDefinition(sql, template, cancellationToken: cancellationToken));
    }

    // Update
    public async Task<int> UpdateAsync(CodingTemplate template, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE coding_templates
SET
    technology_id = @TechnologyId,
    starter_code = @StarterCode,
    solution_code = @SolutionCode,
    updated_by = @UpdatedBy,
    updated_at = @UpdatedAt
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(new CommandDefinition(sql, template, cancellationToken: cancellationToken));
    }

    // Soft Delete
    public async Task<int> SoftDeleteAsync(int id, Guid deletedBy, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE coding_templates
SET
    deleted_by = @DeletedBy,
    deleted_at = @DeletedAt
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(new CommandDefinition(sql,
                new
                {
                    Id = id,
                    DeletedBy = deletedBy,
                    DeletedAt = DateTime.UtcNow
                },
                cancellationToken: cancellationToken));
    }
    
    // Soft delete by Question
    public async Task<int> SoftDeleteByQuestionIdAsync(int questionId, Guid deletedBy, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE coding_templates
SET
    deleted_by = @DeletedBy,
    deleted_at = @DeletedAt
WHERE question_id = @QuestionId
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId,
                    DeletedBy = deletedBy,
                    DeletedAt = DateTime.UtcNow
                },
                cancellationToken: cancellationToken));
    }

    // Get By Id
    public async Task<CodingTemplate?> GetByIdAsync(int id, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    technology_id AS TechnologyId,
    starter_code AS StarterCode,
    solution_code AS SolutionCode,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM coding_templates
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<CodingTemplate>(new CommandDefinition( sql,
                new { Id = id },
                cancellationToken: cancellationToken));
    }

    // Get By Question
    public async Task<IEnumerable<CodingTemplate>> GetByQuestionIdAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    technology_id AS TechnologyId,
    starter_code AS StarterCode,
    solution_code AS SolutionCode,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM coding_templates
WHERE question_id = @QuestionId
AND deleted_at IS NULL
ORDER BY technology_id;";

        using var connection = _context.CreateConnection();
        return await connection.QueryAsync<CodingTemplate>(new CommandDefinition(sql, new { QuestionId = questionId }, cancellationToken: cancellationToken));
    }
}