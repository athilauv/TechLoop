﻿using Dapper;
using TechLoop.Application.Interfaces.Infrastructure;
using TechLoop.Application.Interfaces.Repositories;
using TechLoop.Domain.Entities;

namespace TechLoop.Infrastructure.Repositories;

public sealed class McqOptionRepository : IMcqOptionRepository
{
    private readonly IDapperContext _context;

    public McqOptionRepository(IDapperContext context)
    {
        _context = context;
    }

    // Exists
    public async Task<bool> ExistsAsync(int questionId, string optionText, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT EXISTS
(
    SELECT 1
    FROM mcq_options
    WHERE question_id = @QuestionId
      AND LOWER(option_text) = LOWER(@OptionText)
      AND deleted_at IS NULL
);";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<bool>(new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId,
                    OptionText = optionText
                },
                cancellationToken: cancellationToken));
    }

    // Position Exists
    public async Task<bool> PositionExistsAsync(int questionId, int position, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT EXISTS
(
    SELECT 1
    FROM mcq_options
    WHERE question_id = @QuestionId
      AND position = @Position
      AND deleted_at IS NULL
);";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<bool>(new CommandDefinition(sql,
                new
                {
                    QuestionId = questionId,
                    Position = position
                },
                cancellationToken: cancellationToken));
    }
    
    
    //position count
    public async Task<int> GetOptionCountAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT COUNT(*)
FROM mcq_options
WHERE question_id = @QuestionId
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<int>(
            new CommandDefinition(
                sql,
                new { QuestionId = questionId },
                cancellationToken: cancellationToken));
    }

    // Create
    public async Task<int> CreateAsync(McqOption option, CancellationToken cancellationToken)
    {
        const string sql = @"
INSERT INTO mcq_options
(
    question_id,
    option_text,
    is_correct,
    position,
    created_by,
    created_at
)
VALUES
(
    @QuestionId,
    @OptionText,
    @IsCorrect,
    @Position,
    @CreatedBy,
    @CreatedAt
)
RETURNING id;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<int>(
            new CommandDefinition(sql, option, cancellationToken: cancellationToken));
    }

    // Update
    public async Task<int> UpdateAsync(McqOption option, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE mcq_options
SET
    option_text = @OptionText,
    is_correct = @IsCorrect,
    position = @Position,
    updated_by = @UpdatedBy,
    updated_at = @UpdatedAt
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(new CommandDefinition(sql, option, cancellationToken: cancellationToken));
    }

    // Soft Delete
    public async Task<int> SoftDeleteAsync(int id, Guid deletedBy, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE mcq_options
SET
    deleted_at = @DeletedAt,
    deleted_by = @DeletedBy
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    Id = id,
                    DeletedBy = deletedBy,
                    DeletedAt = DateTime.UtcNow
                },
                cancellationToken: cancellationToken));
    }
    
    //
    public async Task<int> SoftDeleteByQuestionIdAsync(int questionId, Guid deletedBy, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE mcq_options
SET
    deleted_at = @DeletedAt,
    deleted_by = @DeletedBy
WHERE question_id = @QuestionId
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId,
                    DeletedBy = deletedBy,
                    DeletedAt = DateTime.UtcNow
                },
                cancellationToken: cancellationToken));
    }
    
    
    public async Task<bool> HasCorrectOptionAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT EXISTS
(
    SELECT 1
    FROM mcq_options
    WHERE question_id = @QuestionId
    AND is_correct = TRUE
    AND deleted_at IS NULL
);";

        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<bool>(
            new CommandDefinition(
                sql,
                new { QuestionId = questionId },
                cancellationToken: cancellationToken));
    }

    // Get by id
    public async Task<McqOption?> GetByIdAsync(int id, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    option_text AS OptionText,
    is_correct AS IsCorrect,
    position,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM mcq_options
WHERE id = @Id
AND deleted_at IS NULL;";

        using var connection = _context.CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<McqOption>(
            new CommandDefinition(
                sql,
                new { Id = id },
                cancellationToken: cancellationToken));
    }

    // Get by question
    public async Task<IEnumerable<McqOption>> GetByQuestionIdAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"
SELECT
    id,
    question_id AS QuestionId,
    option_text AS OptionText,
    is_correct AS IsCorrect,
    position,
    created_by AS CreatedBy,
    created_at AS CreatedAt,
    updated_by AS UpdatedBy,
    updated_at AS UpdatedAt
FROM mcq_options
WHERE question_id = @QuestionId
AND deleted_at IS NULL
ORDER BY position;";

        using var connection = _context.CreateConnection();
        return await connection.QueryAsync<McqOption>(
            new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId
                },
                cancellationToken: cancellationToken));
    }
}