﻿using Dapper;
using TechLoop.Application.Interfaces.Infrastructure;
using TechLoop.Application.Interfaces.Repositories;
using TechLoop.Domain.Entities;

namespace TechLoop.Infrastructure.Repositories;

public class SubmissionRepository : ISubmissionRepository
{
    private readonly IDapperContext _context;

    public SubmissionRepository(IDapperContext context)
    {
        _context = context;
    }

    // Checks if the user has already submitted the specified question
    public async Task<bool> ExistsAsync(Guid userId, int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"SELECT fn_submission_exists(@UserId, @QuestionId);";
        using var connection = _context.CreateConnection();
        return await connection.ExecuteScalarAsync<bool>(new CommandDefinition(sql,
                new
                {
                    UserId = userId,
                    QuestionId = questionId
                },
                cancellationToken: cancellationToken));
    }

    // Creates a new submission and returns the generated ID
    public async Task<int> CreateAsync(Submission submission, CancellationToken cancellationToken)
    {
//        const string sql = @"SELECT fn_create_submission(@UserId,@QuestionId,@TechnologyId,@SourceCode,@Status,@SubmittedAt);";
        const string sql = @"SELECT pg_typeof(@Status);";
        using var connection = _context.CreateConnection();
        Console.WriteLine(sql);
        var parameters = new
        {
            submission.UserId,
            submission.QuestionId,
            submission.TechnologyId,
            submission.SourceCode,
            submission.Status,
            submission.SubmittedAt
        };

       // return await connection.ExecuteScalarAsync<int>(new CommandDefinition(sql, parameters, cancellationToken: cancellationToken));
       var type = await connection.ExecuteScalarAsync<string>(new CommandDefinition(sql, parameters, cancellationToken: cancellationToken));
       Console.WriteLine($"PostgreSQL type = {type}");
       return 0;
    }

    // Retrieves a submission by its ID
    public async Task<Submission?> GetByIdAsync(int id, CancellationToken cancellationToken)
    {
        Console.WriteLine("========== GetByIdAsync ==========");
        const string sql = @"SELECT * FROM fn_get_submission_by_id(@Id);";
        using var connection = _context.CreateConnection();
        var row = await connection.QuerySingleAsync(
            new CommandDefinition(
                sql,
                new { Id = id },
                cancellationToken: cancellationToken));

        foreach (var item in (IDictionary<string, object>)row)
        {
            Console.WriteLine($"{item.Key} = {item.Value} ({item.Value?.GetType().FullName})");
        }

        Console.WriteLine("==================================");
        return null;
    }

// Retrieves all submissions of the specified user
    public async Task<IEnumerable<Submission>> GetByUserIdAsync(Guid userId, CancellationToken cancellationToken)
    {
        Console.WriteLine("========== GetByUserIdAsync ==========");
        const string sql = @"SELECT * FROM fn_get_user_submissions(@UserId);";
        using var connection = _context.CreateConnection();
        var rows = await connection.QueryAsync(sql,
            new CommandDefinition(
                sql,
                new
                {
                    UserId = userId
                },
                cancellationToken: cancellationToken));

        foreach (IDictionary<string, object> row in rows)
        {
            Console.WriteLine("--------------------------------");
            foreach (var item in row)
            {
                Console.WriteLine($"{item.Key} = {item.Value} ({item.Value?.GetType().FullName})");
            }
        }

        Console.WriteLine("=====================================");
        return Enumerable.Empty<Submission>();
    }

    // Retrieves all submissions for the specified question
    public async Task<IEnumerable<Submission>> GetByQuestionIdAsync(int questionId, CancellationToken cancellationToken)
    {
        const string sql = @"SELECT * FROM fn_get_question_submissions(@QuestionId);";
        using var connection = _context.CreateConnection();
        return await connection.QueryAsync<Submission>(new CommandDefinition(
                sql,
                new
                {
                    QuestionId = questionId
                },
                cancellationToken: cancellationToken));
    }

    // Updates the execution result of the specified submission
    public async Task<int> UpdateResultAsync(Submission submission, CancellationToken cancellationToken)
    {
        const string sql = @"CALL sp_update_submission_result(@Id,@Status,@ExecutionTimeMs,@MemoryUsedMb,@PassedTestCases,@TotalTestCases,@Score,@CompilerOutput,@RuntimeOutput,@AiReview,@JudgeToken);";
        using var connection = _context.CreateConnection();
        return await connection.ExecuteAsync(
            new CommandDefinition(
                sql,
                new
                {
                    submission.Id,
                    submission.Status,
                    submission.ExecutionTimeMs,
                    submission.MemoryUsedMb,
                    submission.PassedTestCases,
                    submission.TotalTestCases,
                    submission.Score,
                    submission.CompilerOutput,
                    submission.RuntimeOutput,
                    submission.AiReview,
                    submission.JudgeToken
                },
                cancellationToken: cancellationToken));
    }
}